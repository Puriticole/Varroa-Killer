# maixpy-openmv-demos
Codes and micropython binary for Sipeed MaiX Bit OpenMV demos

Examples are from OpenMV Github repository with some minor changes to work with Sipeed MaiX Bit and enbale video recording.
Micropython binary is comiled using source code from MaixPy Github repository.
